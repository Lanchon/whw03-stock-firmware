#!/bin/sh

#-------------------------------------------------------------------------------
# © 2016 Belkin International, Inc. and/or its affiliates. All rights reserved.
#-------------------------------------------------------------------------------

# startup firmware update check


MOD=fwupc
MOD=$(which $MOD) && $MOD &

