#!/bin/sh
. /etc/init.d/hotplug2_functions.sh
FactoryResetAfter $1
